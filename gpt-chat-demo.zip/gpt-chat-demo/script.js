document.getElementById("send-button").addEventListener("click", function() {
    var userInput = document.getElementById("user-input").value;
    if (userInput !== "") {
        var messageContainer = document.getElementById("message-container");
        var userMessage = document.createElement("div");
        userMessage.classList.add("message", "user");
        userMessage.innerHTML = `
            <div class="message-content">
                <p>${userInput}</p>
            </div>
        `;
        messageContainer.appendChild(userMessage);

        // 清空输入框
        document.getElementById("user-input").value = "";
    }
});